package com.rentablezone.app

import android.annotation.SuppressLint
import android.location.Address
import android.location.Geocoder
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale
import java.util.concurrent.Executors

class ZonesActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private lateinit var list: TextView
    private lateinit var spinner: Spinner
    private val executor = Executors.newSingleThreadExecutor()
    private val localities = mutableListOf<SavedLocality>()

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_zones)
        localities.addAll(ZoneStore.loadLocalities(this))
        list = findViewById(R.id.txtSelected)
        spinner = findViewById(R.id.spZone)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            listOf("🟢 Permitida", "🟡 Precaución", "🔴 Peligrosa"))
        findViewById<Button>(R.id.btnClear).setOnClickListener {
            localities.clear(); ZoneStore.saveLocalities(this, localities); updateList(); web.evaluateJavascript("clearAll();", null)
        }
        findViewById<Button>(R.id.btnSave).setOnClickListener {
            ZoneStore.saveLocalities(this, localities); toast("Selección guardada (${localities.size} localidades)")
        }
        updateList()

        web = findViewById(R.id.mapWeb)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.cacheMode = WebSettings.LOAD_DEFAULT
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(MapBridge(), "Android")
        web.loadUrl("file:///android_asset/map.html")
    }

    private inner class MapBridge {
        @JavascriptInterface
        fun mapTapped(lat: Double, lng: Double) {
            executor.execute {
                val address = try {
                    Geocoder(this@ZonesActivity, Locale("es", "AR")).getFromLocation(lat, lng, 1)?.firstOrNull()
                } catch (_: Exception) { null }
                runOnUiThread {
                    if (address == null) {
                        toast("No se pudo identificar la localidad. Acercá el mapa e intentá otra vez.")
                        return@runOnUiThread
                    }
                    val name = localityName(address)
                    if (name.isBlank()) {
                        toast("No se encontró una localidad en ese punto")
                        return@runOnUiThread
                    }
                    toggleLocality(name, lat, lng)
                }
            }
        }
    }

    private fun toggleLocality(name: String, lat: Double, lng: Double) {
        val key = norm(name)
        val existing = localities.indexOfFirst { norm(it.name) == key }
        if (existing >= 0) {
            localities.removeAt(existing)
            toast("$name deseleccionada")
            web.evaluateJavascript("removeLocality(${js(name)});", null)
        } else {
            val type = spinner.selectedItemPosition
            localities.add(SavedLocality(type, name, lat, lng))
            toast("$name seleccionada")
            web.evaluateJavascript("addLocality(${js(name)},$lat,$lng,${type});", null)
        }
        ZoneStore.saveLocalities(this, localities)
        updateList()
    }

    private fun localityName(a: Address): String {
        val raw = a.locality ?: a.subLocality ?: a.subAdminArea ?: a.adminArea ?: a.featureName ?: ""
        return raw.replace("Partido de ", "", ignoreCase = true).trim()
    }

    private fun updateList() {
        list.text = if (localities.isEmpty()) "Ninguna localidad seleccionada"
        else localities.joinToString("\n") { "${label(it.type)} ${it.name}" }
    }

    private fun label(t: Int) = when (t) { 0 -> "🟢"; 1 -> "🟡"; else -> "🔴" }
    private fun norm(s: String) = java.text.Normalizer.normalize(s.lowercase(Locale.getDefault()), java.text.Normalizer.Form.NFD)
        .replace("\\p{M}+".toRegex(), "").trim()
    private fun js(s: String) = "'" + s.replace("\\", "\\\\").replace("'", "\\'") + "'"
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onDestroy() { executor.shutdownNow(); web.destroy(); super.onDestroy() }
    override fun onResume() { super.onResume(); web.onResume() }
    override fun onPause() { web.onPause(); super.onPause() }
}
