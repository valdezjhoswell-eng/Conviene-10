package com.conviene.app

import java.util.Locale

data class Offer(
    val platform: String,
    val price: Double,
    val pickupKm: Double?,
    val tripKm: Double?,
    val minutes: Int?,
    val tolls: Double?,
    val trips: Int?,
    val rating: Double?,
    val verified: Boolean,
    val rawText: String
) {
    val totalKm: Double?
        get() = if (pickupKm != null && tripKm != null) pickupKm + tripKm else tripKm

    val pricePerKm: Double?
        get() = if (totalKm != null && totalKm!! > 0) price / totalKm!! else null

    val approximateHourly: Double?
        get() = if (minutes != null && minutes!! > 0) price * 60.0 / minutes!! else null

    val priceMinusTolls: Double?
        get() = if (tolls != null) price - tolls!! else null
}

object OfferParser {

    private val moneyRegex = Regex("""(?:ARS|\$)?\s*([0-9]{1,3}(?:[.,][0-9]{3})*(?:[.,][0-9]{1,2})?)""")
    private val kmRegex = Regex("""([0-9]+(?:[.,][0-9]+)?)\s*km""", RegexOption.IGNORE_CASE)
    private val minRegex = Regex("""([0-9]+)\s*min""", RegexOption.IGNORE_CASE)
    private val tripsRegex = Regex("""([0-9]+)\s+viajes""", RegexOption.IGNORE_CASE)
    private val ratingRegex = Regex("""([0-9]+[.,][0-9]+)\s*\(""")
    private val tollRegex = Regex("""(?:peajes?|incluyen(?:\s+peajes?)?).{0,30}?([0-9]{1,3}(?:[.,][0-9]{3})*)""", RegexOption.IGNORE_CASE)

    fun parse(text: String): Offer? {
        val t = text.replace("\u00A0", " ").replace("\n", " ")
        val lower = t.lowercase(Locale.ROOT)

        val platform = when {
            "cabify" in lower -> "CABIFY"
            "uber" in lower -> "UBER"
            else -> "OTRA"
        }

        val price = findPrice(t) ?: return null
        val kms = kmRegex.findAll(t).map { parseDecimal(it.groupValues[1]) }.toList()
        val minutes = minRegex.findAll(t).map { it.groupValues[1].toIntOrNull() }.filterNotNull().maxOrNull()
        val trips = tripsRegex.find(t)?.groupValues?.get(1)?.toIntOrNull()
        val rating = ratingRegex.find(t)?.groupValues?.get(1)?.let { parseDecimal(it) }
        val verified = lower.contains("verificado") || lower.contains("verificación de identidad")

        // In the example, the first km is pickup distance and the last is trip distance.
        val pickup = if (kms.size >= 2) kms.first() else null
        val trip = if (kms.isNotEmpty()) kms.last() else null
        val tolls = findTolls(t)

        // Require a plausible offer signature: price + km + time.
        if (kms.isEmpty() || minutes == null) return null

        return Offer(platform, price, pickup, trip, minutes, tolls, trips, rating, verified, text)
    }

    private fun findPrice(t: String): Double? {
        // Prefer a money value close to the beginning of the offer.
        val matches = moneyRegex.findAll(t).toList()
        for (m in matches.take(8)) {
            val value = parseMoney(m.groupValues[1])
            if (value >= 500) return value
        }
        return null
    }

    private fun findTolls(t: String): Double? {
        val match = tollRegex.find(t) ?: return null
        return parseMoney(match.groupValues[1])
    }

    private fun parseMoney(s: String): Double {
        val x = s.replace(" ", "")
        return when {
            x.contains(".") && x.contains(",") -> x.replace(".", "").replace(",", ".").toDoubleOrNull() ?: 0.0
            x.count { it == '.' } >= 1 && x.substringAfterLast('.').length == 3 ->
                x.replace(".", "").toDoubleOrNull() ?: 0.0
            x.count { it == ',' } >= 1 && x.substringAfterLast(',').length == 3 ->
                x.replace(",", "").toDoubleOrNull() ?: 0.0
            else -> x.replace(",", ".").toDoubleOrNull() ?: 0.0
        }
    }

    private fun parseDecimal(s: String): Double {
        return s.replace(".", "").replace(",", ".").toDoubleOrNull()
            ?: s.replace(",", ".").toDoubleOrNull()
            ?: 0.0
    }
}
