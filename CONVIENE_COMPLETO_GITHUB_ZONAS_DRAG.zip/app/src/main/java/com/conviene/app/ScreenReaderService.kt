package com.conviene.app

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.*
import android.view.Gravity
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.view.MotionEvent
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.atomic.AtomicBoolean

class ScreenReaderService : Service() {

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var overlay: LinearLayout? = null
    private var overlayText: TextView? = null
    private var overlayHeader: TextView? = null
    private var overlayParams: WindowManager.LayoutParams? = null
    private var dragStartX = 0f
    private var dragStartY = 0f
    private var dragOriginX = 0
    private var dragOriginY = 0
    private var wm: WindowManager? = null
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val processing = AtomicBoolean(false)
    private var lastValidOfferAt = 0L
    private val hideDelayMs = 2200L
    private val handler = Handler(Looper.getMainLooper())

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForegroundNotification()

        val resultCode = intent?.getIntExtra("resultCode", 0) ?: return START_NOT_STICKY
        val data = intent.getParcelableExtra<Intent>("data") ?: return START_NOT_STICKY

        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as android.media.projection.MediaProjectionManager
        projection = manager.getMediaProjection(resultCode, data)

        createCapture()
        createOverlay()
        return START_NOT_STICKY
    }

    private fun createCapture() {
        val metrics = resources.displayMetrics
        reader = ImageReader.newInstance(
            metrics.widthPixels,
            metrics.heightPixels,
            PixelFormat.RGBA_8888,
            2
        )

        projection?.createVirtualDisplay(
            "CONVIENE_SCREEN_READER",
            metrics.widthPixels,
            metrics.heightPixels,
            metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader!!.surface,
            null,
            handler
        )

        reader?.setOnImageAvailableListener({ ir ->
            if (!processing.compareAndSet(false, true)) {
                ir.acquireLatestImage()?.close()
                return@setOnImageAvailableListener
            }

            val image = ir.acquireLatestImage()
            if (image == null) {
                processing.set(false)
                return@setOnImageAvailableListener
            }

            val plane = image.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * image.width

            val bitmap = Bitmap.createBitmap(
                image.width + rowPadding / pixelStride,
                image.height,
                Bitmap.Config.ARGB_8888
            )
            bitmap.copyPixelsFromBuffer(buffer)
            image.close()

            val cropped = Bitmap.createBitmap(bitmap, 0, 0, image.width, image.height)
            bitmap.recycle()

            val input = InputImage.fromBitmap(cropped, 0)
            recognizer.process(input)
                .addOnSuccessListener { result ->
                    val offer = OfferParser.parse(result.text)
                    if (offer != null) {
                        lastValidOfferAt = System.currentTimeMillis()
                        showOffer(offer)
                    } else if (System.currentTimeMillis() - lastValidOfferAt > hideDelayMs) {
                        hideOverlay()
                    }
                    cropped.recycle()
                    processing.set(false)
                }
                .addOnFailureListener {
                    cropped.recycle()
                    processing.set(false)
                }
        }, handler)
    }

    private fun createOverlay() {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        overlayHeader = TextView(this).apply {
            text = "CONVIENE  •  ARRASTRAR AQUÍ"
            textSize = 12f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(20, 12, 20, 12)
            setBackgroundColor(0xFF333333.toInt())
            setOnTouchListener { _, event ->
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        dragStartX = event.rawX
                        dragStartY = event.rawY
                        dragOriginX = overlayParams?.x ?: 0
                        dragOriginY = overlayParams?.y ?: 90
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val p = overlayParams ?: return@setOnTouchListener true
                        p.x = dragOriginX + (event.rawX - dragStartX).toInt()
                        p.y = dragOriginY + (event.rawY - dragStartY).toInt()
                        try { wm?.updateViewLayout(overlay, p) } catch (_: Exception) {}
                        true
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        saveOverlayPosition()
                        true
                    }
                    else -> true
                }
            }
        }

        overlayText = TextView(this).apply {
            textSize = 14f
            setTextColor(0xFF202020.toInt())
            setPadding(20, 14, 20, 18)
            setBackgroundColor(0xEEF5F5F5.toInt())
        }

        overlay = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(overlayHeader)
            addView(overlayText)
        }

        val prefs = getSharedPreferences("conviene_overlay", Context.MODE_PRIVATE)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = prefs.getInt("x", 20)
        params.y = prefs.getInt("y", 90)
        overlayParams = params

        wm?.addView(overlay, params)
        overlay?.visibility = android.view.View.GONE
    }

    private fun saveOverlayPosition() {
        val p = overlayParams ?: return
        getSharedPreferences("conviene_overlay", Context.MODE_PRIVATE).edit()
            .putInt("x", p.x).putInt("y", p.y).apply()
    }

    private fun showOffer(o: Offer) {
        handler.post {
            val zones = ZoneStore.load(this)
            val textLower = o.rawText.lowercase(java.util.Locale.ROOT)
            val matched = zones
                .filter { textLower.contains(it.name.lowercase(java.util.Locale.ROOT)) }
                .maxByOrNull { it.name.length }

            overlay?.visibility = android.view.View.VISIBLE
            overlayText?.text = buildString {
                when (matched?.level) {
                    RiskLevel.RED -> append("🔴 NO CONVIENE — LOCALIDAD MARCADA ROJA\n")
                    RiskLevel.YELLOW -> append("🟡 OBSERVACIÓN — LOCALIDAD MARCADA AMARILLA\n")
                    RiskLevel.GREEN -> append("🟢 ACEPTABLE — LOCALIDAD MARCADA VERDE\n")
                    null -> append("CONVIENE — ZONA SIN CLASIFICAR\n")
                }
                append("${o.platform}   $${money(o.price)}\n")
                append("Viaje: ${o.tripKm?.let { decimal(it) } ?: "-"} km")
                if (o.pickupKm != null) append("   •   Recogida: ${decimal(o.pickupKm)} km")
                append("\nTiempo: ${o.minutes ?: "-"} min")
                if (o.totalKm != null) append("\nTotal aprox.: ${decimal(o.totalKm!!)} km")
                if (o.pricePerKm != null) append("\n$/km: $${money(o.pricePerKm!!)}")
                if (o.approximateHourly != null) append("\n$/hora aprox.: $${money(o.approximateHourly!!)}")
                if (o.tolls != null) append("\nPeajes detectados: $${money(o.tolls!!)}")
                if (o.trips != null) append("\nViajes: ${o.trips}")
                if (o.rating != null) append("\nCalificación: ${decimal(o.rating!!)}")
                if (o.verified) append("\nVerificado: sí")
                if (matched != null) append("\nLocalidad: ${matched.name}")
                append("\n\nSOLO INFORMACIÓN. NO ACEPTA NI RECHAZA NADA.")
            }
        }
    }

    private fun hideOverlay() {
        handler.post {
            overlay?.visibility = android.view.View.GONE
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        hideOverlay()
        reader?.close()
        projection?.stop()
        recognizer.close()
        overlay?.let { view ->
            try { wm?.removeView(view) } catch (_: Exception) {}
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun money(v: Double): String =
        String.format(java.util.Locale.US, "%,.0f", v).replace(",", ".")

    private fun decimal(v: Double): String =
        String.format(java.util.Locale.US, "%.1f", v).replace(".", ",")

    private fun startForegroundNotification() {
        val channelId = "conviene_reader"
        val channel = NotificationChannel(
            channelId,
            "CONVIENE — lector de pantalla",
            NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)

        val notification = Notification.Builder(this, channelId)
            .setContentTitle("CONVIENE activo")
            .setContentText("Solo lectura de pantalla. No controla otras apps.")
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setOngoing(true)
            .build()

        startForeground(10, notification)
    }
}
