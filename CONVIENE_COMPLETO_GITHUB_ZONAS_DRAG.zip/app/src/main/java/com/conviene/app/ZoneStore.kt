package com.conviene.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

enum class RiskLevel { GREEN, YELLOW, RED }

data class RiskCircle(
    val name: String,
    val lat: Double,
    val lon: Double,
    val radiusMeters: Double,
    val level: RiskLevel = RiskLevel.RED
)

object ZoneStore {
    private const val PREFS = "conviene_zones"
    private const val KEY = "risk_circles"

    fun load(context: Context): List<RiskCircle> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY, "[]") ?: "[]"
        val array = JSONArray(raw)
        val result = mutableListOf<RiskCircle>()
        for (i in 0 until array.length()) {
            val o = array.getJSONObject(i)
            result += RiskCircle(
                o.getString("name"),
                o.getDouble("lat"),
                o.getDouble("lon"),
                o.getDouble("radius"),
                runCatching { RiskLevel.valueOf(o.optString("level", "RED")) }.getOrDefault(RiskLevel.RED)
            )
        }
        return result
    }

    fun save(context: Context, zones: List<RiskCircle>) {
        val array = JSONArray()
        zones.forEach {
            array.put(
                JSONObject()
                    .put("name", it.name)
                    .put("lat", it.lat)
                    .put("lon", it.lon)
                    .put("radius", it.radiusMeters)
                    .put("level", it.level.name)
            )
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY, array.toString()).apply()
    }
}
