package com.conviene.app

import android.Manifest
import android.content.pm.PackageManager
import android.location.Address
import android.location.Geocoder
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.osmdroid.config.Configuration
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Circle
import org.osmdroid.views.overlay.Marker
import java.util.Locale

class ZoneActivity : ComponentActivity() {
    private lateinit var map: MapView
    private val zones = mutableListOf<RiskCircle>()
    private var selectedPoint: GeoPoint? = null
    private var selectedLevel = RiskLevel.RED
    private lateinit var localityInput: EditText
    private lateinit var radiusInput: EditText
    private lateinit var status: TextView
    private lateinit var listBox: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Configuration.getInstance().load(applicationContext, getSharedPreferences("osmdroid", MODE_PRIVATE))
        zones.addAll(ZoneStore.load(this))

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val title = TextView(this).apply {
            text = "CONVIENE — ZONAS POR LOCALIDAD"
            textSize = 20f
            setPadding(24, 18, 24, 8)
        }
        val help = TextView(this).apply {
            text = "Busca una localidad o toca el mapa. Luego marca VERDE, AMARILLA u ROJA y guarda."
            setPadding(24, 0, 24, 12)
        }
        root.addView(title)
        root.addView(help)

        val searchRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        localityInput = EditText(this).apply {
            hint = "Localidad (ej. Palermo)"
            singleLine = true
        }
        searchRow.addView(localityInput, LinearLayout.LayoutParams(0, -2, 1f))
        searchRow.addView(Button(this).apply {
            text = "BUSCAR"
            setOnClickListener { searchLocality() }
        })
        root.addView(searchRow)

        map = MapView(this).apply {
            setMultiTouchControls(true)
            controller.setZoom(11.5)
            controller.setCenter(GeoPoint(-34.6037, -58.3816))
        }
        root.addView(map, LinearLayout.LayoutParams(-1, 0, 1f))

        status = TextView(this).apply {
            text = "Toca el mapa para seleccionar el centro."
            setPadding(24, 10, 24, 4)
        }
        root.addView(status)

        val levelRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        levelRow.addView(levelButton("🟢 VERDE", RiskLevel.GREEN))
        levelRow.addView(levelButton("🟡 AMARILLA", RiskLevel.YELLOW))
        levelRow.addView(levelButton("🔴 ROJA", RiskLevel.RED))
        root.addView(levelRow)

        radiusInput = EditText(this).apply {
            hint = "Radio de localidad en metros (ej. 1500)"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setText("1500")
        }
        root.addView(radiusInput)
        root.addView(Button(this).apply {
            text = "GUARDAR LOCALIDAD"
            setOnClickListener { saveSelected() }
        })

        val filterRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("TODAS" to null, "🟢 VERDES" to RiskLevel.GREEN, "🟡 AMARILLAS" to RiskLevel.YELLOW, "🔴 ROJAS" to RiskLevel.RED).forEach { (label, level) ->
            filterRow.addView(Button(this).apply {
                text = label
                setOnClickListener { showFiltered(level) }
            })
        }
        root.addView(filterRow)
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(listBox)
        setContentView(root)

        map.setOnTouchListener { _, event ->
            if (event.action == android.view.MotionEvent.ACTION_UP) {
                selectedPoint = map.projection.fromPixels(event.x.toInt(), event.y.toInt())
                status.text = "Punto seleccionado: %.5f, %.5f".format(Locale.US, selectedPoint!!.latitude, selectedPoint!!.longitude)
                drawZones()
            }
            false
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 55)
        }
        drawZones()
        showFiltered(null)
    }

    private fun levelButton(label: String, level: RiskLevel): Button = Button(this).apply {
        text = label
        setOnClickListener {
            selectedLevel = level
            status.text = "Nivel seleccionado: ${label.substringAfter(' ')}"
        }
    }

    private fun searchLocality() {
        val query = localityInput.text.toString().trim()
        if (query.isBlank()) return
        try {
            val results: List<Address> = Geocoder(this, Locale.getDefault()).getFromLocationName(query, 1) ?: emptyList()
            val address = results.firstOrNull()
            if (address == null) {
                Toast.makeText(this, "No encontré esa localidad. Prueba otro nombre.", Toast.LENGTH_SHORT).show()
                return
            }
            selectedPoint = GeoPoint(address.latitude, address.longitude)
            map.controller.setCenter(selectedPoint)
            map.controller.setZoom(14.0)
            status.text = "Localidad encontrada: ${address.locality ?: query}. Elige el color y guarda."
            drawZones()
        } catch (e: Exception) {
            Toast.makeText(this, "No se pudo buscar. Revisa la conexión y vuelve a intentar.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun saveSelected() {
        val point = selectedPoint
        if (point == null) {
            Toast.makeText(this, "Primero busca una localidad o toca el mapa.", Toast.LENGTH_SHORT).show()
            return
        }
        val typed = localityInput.text.toString().trim()
        val name = typed.ifBlank { "Localidad ${String.format(Locale.US, "%.4f", point.latitude)}" }
        val meters = radiusInput.text.toString().toDoubleOrNull()?.coerceAtLeast(100.0) ?: 1500.0
        zones.removeAll { it.name.equals(name, ignoreCase = true) }
        zones += RiskCircle(name, point.latitude, point.longitude, meters, selectedLevel)
        ZoneStore.save(this, zones)
        drawZones()
        showFiltered(null)
        Toast.makeText(this, "$name guardada como ${selectedLevel.name}", Toast.LENGTH_SHORT).show()
    }

    private fun showFiltered(level: RiskLevel?) {
        if (!::listBox.isInitialized) return
        listBox.removeAllViews()
        zones.filter { level == null || it.level == level }.forEach { z ->
            val label = TextView(this).apply {
                text = "${levelEmoji(z.level)} ${z.name}"
                textSize = 15f
                setPadding(24, 5, 24, 5)
            }
            listBox.addView(label)
        }
    }

    private fun levelEmoji(level: RiskLevel) = when (level) {
        RiskLevel.GREEN -> "🟢"
        RiskLevel.YELLOW -> "🟡"
        RiskLevel.RED -> "🔴"
    }

    private fun drawZones() {
        map.overlays.clear()
        zones.forEach { z ->
            val point = GeoPoint(z.lat, z.lon)
            val (fill, stroke) = when (z.level) {
                RiskLevel.GREEN -> 0x3322AA22 to 0xFF22AA22.toInt()
                RiskLevel.YELLOW -> 0x33D9A300 to 0xFFD9A300.toInt()
                RiskLevel.RED -> 0x33DD2222 to 0xFFDD2222.toInt()
            }
            map.overlays.add(Circle(map).apply {
                center = point; radius = z.radiusMeters; fillColor = fill; strokeColor = stroke; strokeWidth = 4f; title = z.name
            })
            map.overlays.add(Marker(map).apply { position = point; title = "${levelEmoji(z.level)} ${z.name}" })
        }
        selectedPoint?.let { p ->
            map.overlays.add(Marker(map).apply { position = p; title = "Punto seleccionado" })
        }
        map.invalidate()
    }

    override fun onResume() { super.onResume(); map.onResume() }
    override fun onPause() { map.onPause(); super.onPause() }
}
