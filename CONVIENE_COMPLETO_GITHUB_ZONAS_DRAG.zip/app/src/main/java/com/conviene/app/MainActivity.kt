package com.conviene.app

import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
        }

        val title = TextView(this).apply {
            text = "CONVIENE"
            textSize = 30f
        }

        val subtitle = TextView(this).apply {
            text = "\nLee la oferta visible en pantalla y solo muestra información.\n\nNO acepta ni rechaza viajes. NO controla Uber ni Cabify."
            textSize = 17f
        }

        val start = Button(this).apply {
            text = "ACTIVAR LECTOR"
            setOnClickListener { requestReader() }
        }

        val stop = Button(this).apply {
            text = "DETENER LECTOR"
            setOnClickListener {
                stopService(Intent(this@MainActivity, ScreenReaderService::class.java))
            }
        }

        val zones = Button(this).apply {
            text = "CONFIGURAR ZONAS DE RIESGO"
            setOnClickListener {
                startActivity(Intent(this@MainActivity, ZoneActivity::class.java))
            }
        }

        val info = TextView(this).apply {
            text = "\nFiltros incluidos:\n• mínimo $/km\n• zona de riesgo\n\nEl filtro de tiempo máximo fue eliminado.\n\nNo existe registro de aceptación/rechazo."
            textSize = 16f
        }

        root.addView(title)
        root.addView(subtitle)
        root.addView(start)
        root.addView(stop)
        root.addView(zones)
        root.addView(info)
        setContentView(root)
    }

    private fun requestReader() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
            return
        }

        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE)
    }

    @Deprecated("Android API compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CAPTURE && resultCode == RESULT_OK && data != null) {
            val service = Intent(this, ScreenReaderService::class.java).apply {
                putExtra("resultCode", resultCode)
                putExtra("data", data)
            }
            startForegroundService(service)
        }
    }

    companion object {
        private const val REQUEST_CAPTURE = 7001
    }
}
