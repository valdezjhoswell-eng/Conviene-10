# Ejecutar en GitHub

1. Crea un repositorio nuevo en GitHub.
2. Sube todo el contenido de este ZIP conservando las carpetas.
3. Abre la pestaña Actions.
4. Ejecuta "Android build" con "Run workflow".
5. Al terminar, entra al workflow y descarga el artefacto "CONVIENE-debug".
6. Ese artefacto contiene `app-debug.apk`.

No se necesita GitHub Pages ni un backend.
