# CONVIENE

Aplicación Android para **leer y analizar visualmente una oferta que ya está visible en pantalla**.

## Regla fundamental

CONVIENE **NO controla Uber ni Cabify**.

No hace clic, no acepta, no rechaza, no desliza, no pulsa botones y no usa AccessibilityService para actuar sobre otras aplicaciones.

CONVIENE solamente:
1. captura la pantalla con el permiso explícito de Android (MediaProjection);
2. reconoce texto de la oferta con OCR;
3. calcula y muestra información;
4. desaparece automáticamente cuando deja de detectar una oferta válida;
5. permite configurar zonas de riesgo;
6. no exige que el conductor registre si aceptó o rechazó.

## Qué reconoce

El parser está preparado para ejemplos como:

Cabify:
- $ 24.466
- 9 min · 3 km
- 41 min · 29.5 km
- + $ 1.192 al pasar peajes
- 78 viajes

Uber:
- 13.178 ARS
- A 3 min (0.7 km) de distancia
- Viaje de 38 min (19.0 km)
- Se incluyen +1.365,00 ARS

## Cálculos

- distancia total aproximada = distancia hasta pasajero + distancia del viaje;
- $/km;
- $/hora aproximado usando el tiempo del viaje;
- precio menos peajes cuando fueron detectados.

## Zona de riesgo

La versión incluida permite dibujar zonas circulares sobre el mapa. Se guardan localmente.
La primera versión del detector de riesgo intenta usar las coordenadas GPS disponibles para comprobar si el vehículo está dentro de una zona de riesgo.

El reconocimiento automático del texto de una dirección y su geocodificación se deja desacoplado para poder añadirlo sin tocar el lector.

## Importante sobre Android

Android muestra un aviso de captura de pantalla y una notificación permanente mientras MediaProjection está activa. Esto es obligatorio por seguridad del sistema.

La ventana de CONVIENE es `NOT_TOUCHABLE`: no puede recibir toques y por diseño no puede accionar otra app.

## Compilar

Abrir el proyecto en Android Studio y sincronizar Gradle.

También incluye workflow de GitHub Actions en `.github/workflows/android.yml`.

El APK de debug queda en:
`app/build/outputs/apk/debug/app-debug.apk`

## Zonas por localidad (actualización)
- Desde el mapa integrado se puede buscar una localidad por nombre o tocar directamente el mapa.
- Cada localidad se guarda como 🟢 VERDE (aceptable), 🟡 AMARILLA (observación) o 🔴 ROJA (no conveniente).
- Hay filtros para ver todas, verdes, amarillas o rojas.
- El lector compara el texto visible de la oferta con las localidades configuradas y muestra el nivel correspondiente.
- La tarjeta de CONVIENE se puede arrastrar desde su encabezado y recuerda su posición.
- CONVIENE sigue siendo exclusivamente informativa: no pulsa, acepta, rechaza ni controla Uber/Cabify.
